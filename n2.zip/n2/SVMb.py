import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split

np.random.seed(0)

print("X:")
x = np.random.randn(200, 2)
print(x[:5])

y = np.logical_xor(x[:, 0] > 0, x[:, 1] > 0)

def plot_gate(x, y,title):
    plt.title(title)
    plt.scatter(x[:, 0], x[:, 1], c=y, cmap='bwr', marker='x')
    plt.show()

plot_gate(x, y,"XOR")

x_train,x_test,y_train,y_test = train_test_split(x, y, test_size=0.25, random_state=42)

classifier = SVC(kernel='rbf', random_state=0)
classifier.fit(x_train, y_train)
y_pred=classifier.predict(x_test)
print("Classification Report")
print(classification_report(y_test,y_pred))
z=classifier.predict(x)
plot_gate(x, z, "Predicted")