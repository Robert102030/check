import numpy as np

X = np.array([[0, 0],[0, 1],[1, 0],[1, 1]])
y = np.array([0, 1, 1, 1])
print("OR Gate:")
for i in range(len(X)):
    print(X[i], y[i])

weights = np.zeros((2, 1))
bias = 0.0
print("\nInitial Weights:")
print(weights, bias)

def step_func(z):
    return 1 if z > 0 else 0

lr = 0.1
epochs = 100
for epoch in range(epochs):
    for i in range(len(X)):
       
        z = np.dot(X[i], weights) + bias
        y_pred = step_func(z)
        
        error = y[i] - y_pred
        weights += lr * error * X[i].reshape(2, 1)
        bias += lr * error
print("\nTrained Weights:")
print(weights, bias)

print("\nOR Gate(predicted):")
correct = 0
for i in range(len(X)):
    z = np.dot(X[i], weights) + bias
    prediction = step_func(z)
    print(X[i], [prediction])
    if prediction == y[i]:
        correct += 1

accuracy = correct / len(X)
print("\nAccuracy:", accuracy)