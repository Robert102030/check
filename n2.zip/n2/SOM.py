class SOM : 
# Function here computes the winning vector by Euclidean distance 
    def winner( self, weights, sample ) : 
        D0 = 0 
        D1 = 0 
        for i in range(len(sample)): 
            D0 += (sample[i] - weights[0][i]) ** 2 
            D1 += (sample[i] - weights[1][i]) ** 2 
        if D0<D1: 
            return 0 
        return 1 # Else Return 1 
    # Function here updates the winning vector 
    def update(self,weights, sample, j, alpha ,y) : 
        if y==j:
            for i in range(len(sample)): 
                weights[j][i] += alpha * (sample[i] - weights[j][i]) 
        else:
            for i in range(len(sample)): 
                weights[j][i] -= alpha * (sample[i] - weights[j][i])
        return weights 
        
        
T = [ [ 1, 1, 0, 0 ], [ 0, 0, 0, 1 ], [ 1, 0, 0, 0 ], [ 0, 0, 1, 1 ] , [1, 0, 0, 1],[1, 1, 1, 0]] 
y = [0, 1, 0, 1, 1, 0]


weights=[]
weights.append(T.pop(0))
weights.append(T.pop(0))
y.pop(0)
y.pop(0)
      
m, n = len( T ), len( T[0] ) 
 
ob = SOM() 
epochs = 3
alpha = 0.5 
for i in range( epochs ):
    for j in range( m ) :
        sample = T[j] 
        J = ob.winner( weights, sample ) 
        weights = ob.update(weights,sample,J,alpha,y[j]) 

s = [1,0,0,1] 
J = ob.winner( weights, s ) 
print( "Test Sample s belongs to Cluster : ", J ) 
print( "Trained weights : ",weights ) 