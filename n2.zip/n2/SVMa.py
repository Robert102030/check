import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 
from matplotlib.colors import ListedColormap 
from sklearn.preprocessing import StandardScaler 
from sklearn.model_selection import train_test_split 
from sklearn.metrics import confusion_matrix, accuracy_score 
from sklearn.svm import SVC 

df = pd.read_csv("D:\check\Social_Network_Ads.csv") 
print(df.head()) 
X = df.iloc[:, [2, 3]].values 
y = df.iloc[:, 4].values 
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0) 
sc = StandardScaler() 
x_train = sc.fit_transform(x_train) 
x_test = sc.transform(x_test) 
classifier = SVC(kernel='rbf', random_state=0) 
classifier.fit(x_train, y_train) 
y_pred = classifier.predict(x_test) 
cm = confusion_matrix(y_pred, y_test) 
accuracy = accuracy_score(y_pred, y_test)
print("Confusion Matrix:\n", cm) 
print("Accuracy:", accuracy) 
X1, X2 = np.meshgrid( np.arange(start=x_test[:, 0].min()-1, stop=x_test[:, 0].max() + 1, step=0.01), np.arange(start=x_test[:, 1].min()-1, stop=x_test[:, 1].max() + 1, step=0.01) )
z=classifier.predict(np.array([X1.ravel(), X2.ravel()]).T).reshape(X1.shape)
plt.contourf( X1, X2, z, alpha=0.75, cmap = ListedColormap(('red', 'green')) ) 
plt.scatter(x_test[:,0], x_test[:,1], c=y_test,cmap=ListedColormap(('red', 'green'))) 
plt.title('SVM(Test set)') 
plt.xlabel('Age') 
plt.xticks(()) 
plt.yticks(()) 
plt.ylabel('Estimated Salary') 
plt.legend() 
plt.show()