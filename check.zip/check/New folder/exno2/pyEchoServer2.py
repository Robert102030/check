import socket
from colorama import init, Fore
init() 
HOST = '127.0.0.1'
PORT = 9998
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.listen(1)
print(Fore.GREEN + "Server is waiting for a connection...")
conn, addr = s.accept()
print(Fore.YELLOW + f"Connected by {addr}")
while True:
    data = conn.recv(1024)
    if not data:
        break

    print(Fore.CYAN + "Received:", data.decode())
    conn.send(data)
conn.close()