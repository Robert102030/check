import socket
from colorama import init, Fore

init()

HOST = '127.0.0.1'
PORT = 9998

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))

message = "Hello, Good morning"
print(Fore.BLUE + "Sending:", message)

s.send(message.encode())

data = s.recv(1024)

print(Fore.MAGENTA + "Received:", data.decode())

s.close()