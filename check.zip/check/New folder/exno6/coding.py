import urllib.request
urllib.request.urlretrieve("https://example.com", "webpage.html")
for line in open("webpage.html"):
    print(line.strip())
    
