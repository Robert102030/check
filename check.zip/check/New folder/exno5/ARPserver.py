import socket
UDP_IP="localhost"
UDP_PORT=9090
sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
sock.bind((UDP_IP,UDP_PORT))
ip=["172.16.1.19","172.16.1.8"]
mac=["6A:08:AA:C2","8A:BC:E3:FA"]
while True:
    data,addr=sock.recvfrom(1024)
    str1=data.decode('utf-8')
    l=len(data)
    if l!=0:
        print("Received message:",str1)
        break
if str1 in ip:
    ind = ip.index(str1)
    print("The MAC Address is:", mac[ind])
else:
    print("IP address not found.")